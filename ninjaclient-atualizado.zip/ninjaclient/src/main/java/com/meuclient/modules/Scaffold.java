package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.CactusBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.MagmaBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Scaffold: poe blocos automaticamente embaixo dos seus pes enquanto voce anda,
 * para voce atravessar vazio, rios ou lava sem parar. Usa os blocos da hotbar
 * (ignora blocos que caem, como areia, e blocos com inventario, como baus).
 *
 * Estilo de ponte legit (de jogador bom):
 *  - UMA linha de blocos, um por vez, so embaixo dos seus pes (nada de varias fileiras);
 *  - coloca so quando voce esta saindo da borda (1 tick a frente);
 *  - apoia primeiro no bloco de tras (o da ponte), depois nos lados;
 *  - 1 a 3 ticks aleatorios entre um bloco e outro.
 *
 * Como funciona a cada tick:
 *  1. calcula o bloco embaixo de voce (1 tick a frente pela velocidade);
 *  2. se esta vazio, escolhe o apoio: tras, lados, depois baixo;
 *  3. troca para um bloco da hotbar e coloca, com a mira silenciosa (a camera
 *     nao se mexe);
 *  4. depois de cada bloco, devolve na hora o item que voce estava segurando.
 */
public class Scaffold extends Module {
    private int delay;
    private boolean warnedNoBlocks;
    private final java.util.Random random = new java.util.Random();

    public Scaffold() {
        super("Scaffold", Category.WORLD);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onEnable() { delay = 0; warnedNoBlocks = false; }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        if (delay > 0) { delay--; return; }

        // pausa na agua, planando de elytra ou voando (nao faz sentido fazer ponte)
        String pose = mc.player.getPose().name();
        if (mc.player.isTouchingWater() || mc.player.getAbilities().flying
                || pose.equals("GLIDING") || pose.equals("FALL_FLYING")) return;

        int slot = findBlockSlot();
        if (slot == -1) {
            if (!warnedNoBlocks) {
                warnedNoBlocks = true;
                mc.player.sendMessage(net.minecraft.text.Text.literal("§7[NinjaClient] §cScaffold: sem blocos na hotbar"), true);
            }
            return;
        }
        warnedNoBlocks = false;

        // bloco logo abaixo dos pes, so 1 tick a frente: coloca no instante em que
        // voce esta saindo da borda, como um jogador bom fazendo ponte
        Vec3d vel = mc.player.getVelocity();
        BlockPos target = BlockPos.ofFloored(
                mc.player.getX() + vel.x,
                mc.player.getY() - 1.0,
                mc.player.getZ() + vel.z);
        if (!mc.world.getBlockState(target).isReplaceable()) return; // ja tem chao: nada a fazer

        // lado de onde voce vem: o bloco de tras e o apoio natural da ponte
        double hSpeed = Math.hypot(vel.x, vel.z);
        Direction moving = hSpeed > 0.03
                ? Direction.getFacing(vel.x, 0, vel.z)
                : mc.player.getHorizontalFacing();

        // ordem de apoio: bloco de tras, depois os dos lados, por ultimo o de baixo
        Direction[] order = {
                moving.getOpposite(),
                moving.rotateYClockwise(),
                moving.rotateYCounterclockwise(),
                moving,
                Direction.DOWN};

        for (Direction d : order) {
            BlockPos support = target.offset(d);
            BlockState st = mc.world.getBlockState(support);
            if (st.isAir() || st.isReplaceable()) continue;
            // face do apoio que aponta para o bloco novo
            boolean placed = place(target, d.getOpposite(), slot);
            // ritmo humano: 1 a 3 ticks entre blocos (se falhou, tenta de novo no proximo tick)
            delay = placed ? 1 + random.nextInt(3) : 0;
            return; // exatamente UM bloco por vez, so em linha reta
        }
    }

    private boolean place(BlockPos target, Direction faceOfSupport, int slot) {
        BlockPos support = target.offset(faceOfSupport.getOpposite());
        Vec3d hit = Vec3d.ofCenter(support).add(new Vec3d(
                faceOfSupport.getOffsetX(), faceOfSupport.getOffsetY(), faceOfSupport.getOffsetZ()).multiply(0.5));

        // troca so para colocar e devolve o item na hora (antes ficava com o bloco na mao ate desligar)
        int previous = mc.player.getInventory().getSelectedSlot();
        boolean swapped = previous != slot;
        if (swapped) mc.player.getInventory().setSelectedSlot(slot);

        // mira silenciosa: olha para o ponto, coloca e devolve a mira real
        var net = mc.getNetworkHandler();
        if (net != null) {
            Vec3d eye = mc.player.getEyePos();
            double dx = hit.x - eye.x, dy = hit.y - eye.y, dz = hit.z - eye.z;
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch,
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        var result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(hit, faceOfSupport, support, false));
        boolean placed = result.isAccepted();
        if (placed) mc.player.swingHand(Hand.MAIN_HAND);

        if (swapped) mc.player.getInventory().setSelectedSlot(previous);

        if (net != null) {
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(),
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }
        return placed;
    }

    /** Bloco da mao se servir; senao a maior pilha que servir na hotbar. */
    private int findBlockSlot() {
        int selected = mc.player.getInventory().getSelectedSlot();
        if (usable(mc.player.getInventory().getStack(selected))) return selected;
        int best = -1, bestCount = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (usable(st) && st.getCount() > bestCount) { best = i; bestCount = st.getCount(); }
        }
        return best;
    }

    /**
     * So blocos CUBO INTEIRO e solidos: ignora blocos que caem (areia), com inventario (bau),
     * meio-blocos/degraus/nucleo pesado etc. (nao formam chao) e blocos que machucam (TNT, cacto, magma).
     */
    private boolean usable(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem bi)) return false;
        Block block = bi.getBlock();
        if (block instanceof FallingBlock || block instanceof BlockEntityProvider) return false;
        if (block instanceof TntBlock || block instanceof CactusBlock || block instanceof MagmaBlock) return false;
        BlockState state = block.getDefaultState();
        if (!state.isSolidBlock(mc.world, BlockPos.ORIGIN)) return false;
        return Block.isShapeFullCube(state.getCollisionShape(mc.world, BlockPos.ORIGIN));
    }
}
