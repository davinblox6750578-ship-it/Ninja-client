package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import com.meuclient.MeuClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * ESP de vida: mostra a vida do jogador MAIS PROXIMO (alvo travado) em cima da cabeca, em PONTOS de
 * vida (ex.: "20 ♥" = 10 coracoes cheios). Atualiza todo frame, entao quando ele
 * leva dano o numero cai na hora. Vida extra (maca dourada) aparece em dourado,
 * ex.: "20 +4 ♥".
 * Cor do numero: verde = vida boa, amarelo = media, vermelho = baixa.
 *
 * O coracao e desenhado pixel a pixel (nao depende de fonte), e a posicao e
 * calculada no TOPO da caixa do jogador, igual ao BoxESP, entao os dois
 * ficam alinhados em qualquer distancia.
 */
public class ESPVida extends Module {
    private static final double NEAR = 0.05;
    private static final double MAX_DIST = 200.0;

    // coracao 7x6: X = vermelho, o = brilho, . = vazio
    private static final String[] HEART = {
            ".XX.XX.",
            "XoXXXXX",
            "XXXXXXX",
            ".XXXXX.",
            "..XXX..",
            "...X..."};

    private static final double SWITCH_MARGIN = 3.0; // outro jogador so "rouba" o alvo se estiver 3+ blocos mais perto

    private static boolean registered;
    private int lockedId = -1;
    private Object lockedWorld; // mundo em que o alvo foi travado (ids de entidade se repetem entre mundos)

    public ESPVida() {
        super("ESPVida", Category.PLAYER);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        if (!registered) {
            registered = true;
            HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                    Identifier.of("ninjaclient", "espvida"), (ctx, tickCounter) -> render(ctx));
        }
    }

    private void render(DrawContext ctx) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        float delta = mc.getRenderTickCounter().getTickProgress(false);
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = com.meuclient.Projection.tanHalfFov(mc);
        double aspect = (double) sw / sh;

        // se o BoxESP estiver ligado, sobe mais para nao cobrir o nome dele
        Module box = MeuClient.modules.get("BoxESP");
        int lift = (box != null && box.isEnabled()) ? 24 : 12;

        // so UM jogador: o alvo fica travado (nao pula entre jogadores quase na mesma distancia)
        PlayerEntity nearest = pickTarget();

        for (PlayerEntity p : (nearest == null ? java.util.List.<PlayerEntity>of() : java.util.List.of(nearest))) {

            // topo da caixa do jogador (mesmos 4 cantos de cima do BoxESP)
            Vec3d pos = com.meuclient.PlayerTracker.renderPos(p, delta);
            double hw = p.getWidth() / 2.0 + 0.05;
            double top = pos.y - 0.05 + p.getHeight() + 0.1;

            double sumX = 0, minY = Double.MAX_VALUE;
            int n = 0;
            for (int i = 0; i < 4; i++) {
                Vec3d corner = new Vec3d(pos.x + ((i & 1) == 0 ? -hw : hw), top, pos.z + ((i & 2) == 0 ? -hw : hw));
                Vec3d d = corner.subtract(camPos);
                double z = d.dotProduct(fwd);
                if (z <= NEAR) continue; // este canto esta atras da camera
                double sx = sw / 2.0 + (d.dotProduct(right) / z) / (tanHalf * aspect) * (sw / 2.0);
                double sy = sh / 2.0 - (d.dotProduct(up) / z) / tanHalf * (sh / 2.0);
                sumX += sx;
                minY = Math.min(minY, sy);
                n++;
            }
            if (n == 0) continue; // jogador atras de voce

            int cx = (int) Math.round(sumX / n);
            int cy = (int) Math.round(minY) - lift;
            if (cx < -60 || cx > sw + 60 || cy < -20 || cy > sh + 20) continue; // fora da tela

            drawHealth(ctx, p, cx, cy);
        }
    }

    /**
     * Antes o alvo era o "mais proximo" recalculado todo frame: com dois jogadores a distancias parecidas
     * (ou outro duelo na mesma arena) o numero trocava de um para o outro, parecendo que a vida
     * mudava sem dano. Agora o alvo fica travado e so troca se ele sumir/morrer/ficar longe,
     * ou se outro jogador chegar bem mais perto (SWITCH_MARGIN blocos).
     */
    private PlayerEntity pickTarget() {
        if (lockedWorld != mc.world) { // trocou de mundo/servidor/dimensao: o id travado nao vale mais
            lockedWorld = mc.world;
            lockedId = -1;
        }
        PlayerEntity locked = null;
        if (lockedId != -1 && mc.world.getEntityById(lockedId) instanceof PlayerEntity l
                && l != mc.player && l.isAlive() && !l.isSpectator() && l.getHealth() > 0
                && mc.player.distanceTo(l) <= MAX_DIST) {
            locked = l;
        }

        PlayerEntity nearest = null;
        double best = MAX_DIST;
        for (PlayerEntity c : mc.world.getPlayers()) {
            if (c == mc.player || !c.isAlive() || c.isSpectator()) continue;
            if (c.getHealth() <= 0) continue;
            double dist = mc.player.distanceTo(c);
            if (dist <= best) { best = dist; nearest = c; }
        }

        if (locked == null || (nearest != null && nearest != locked
                && best + SWITCH_MARGIN < mc.player.distanceTo(locked))) {
            locked = nearest;
        }
        lockedId = locked == null ? -1 : locked.getId();
        return locked;
    }

    private void drawHealth(DrawContext ctx, PlayerEntity p, int cx, int y) {
        float health = p.getHealth();
        float max = Math.max(1f, p.getMaxHealth());
        float absorption = p.getAbsorptionAmount();
        float ratio = Math.min(1f, health / max);

        int color = ratio > 0.6f ? 0xFF55FF55 : ratio > 0.3f ? 0xFFFFFF55 : 0xFFFF5555;

        String hearts = fmt(health);
        String extra = absorption > 0 ? " +" + fmt(absorption) : "";

        int wHearts = mc.textRenderer.getWidth(hearts);
        int wExtra = mc.textRenderer.getWidth(extra);
        int heartW = 7, gap = 3;
        int total = wHearts + wExtra + gap + heartW;

        int x = cx - total / 2;
        ctx.drawText(mc.textRenderer, hearts, x, y, color, true);
        x += wHearts;
        if (absorption > 0) {
            ctx.drawText(mc.textRenderer, extra, x, y, 0xFFFFAA00, true);
            x += wExtra;
        }
        drawHeart(ctx, x + gap, y + 1);
    }

    /** Coracao 7x6 desenhado com retangulos (sem depender de fonte). */
    private void drawHeart(DrawContext ctx, int x, int y) {
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < HEART[row].length(); col++) {
                char c = HEART[row].charAt(col);
                if (c == '.') continue;
                ctx.fill(x + col, y + row, x + col + 1, y + row + 1, c == 'o' ? 0xFFFF9090 : 0xFFE02020);
            }
        }
    }

    /** Vida em pontos inteiros: 20 = 10 coracoes. Ex.: 19.6 -> "20", 3.0 -> "3". Vivo nunca mostra "0". */
    private static String fmt(float v) {
        if (!(v > 0f)) return "0"; // 0, negativo ou NaN
        return String.valueOf(Math.max(1, Math.round(v)));
    }
}
