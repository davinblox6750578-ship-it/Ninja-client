package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.block.enums.VaultState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base dos modulos de caixa (vault) das Trial Chambers.
 * Confere TODO tick as caixas num raio de 4 blocos e, no instante em que o
 * item que flutua nela e o item desejado, troca para a chave certa (na hotbar),
 * clica na caixa e devolve o slot.
 *
 *  - ominousVault: true = so caixa suprema; false = so caixa normal;
 *  - wanted: item que dispara o clique;
 *  - key: chave usada na caixa.
 * Previsao (so se o modulo ligar `predictive`): observa a sequencia de itens exibidos por caixa
 * (ver VaultForecast). Se o servidor repetir um ciclo, o clique sai ANTES do item aparecer, para
 * chegar ao servidor justo quando ele troca (compensa o ping). Sem ciclo, nada e antecipado e
 * o modulo continua reagindo ao item que aparece, como antes.
 * Cada caixa so abre uma vez por jogador: depois de 3 tentativas na mesma caixa
 * ele para, ate o item exibido mudar.
 */
public abstract class VaultSniper extends Module {
    private static final int RADIUS = 4;      // alcance da fechadura da caixa
    private static final int MAX_ATTEMPTS = 3;
    private static final int RESCAN_TICKS = 5;   // varredura de blocos a cada 5 ticks (nao todo tick)
    // Grava cada troca de item observada (so modulos com previsao) em <pasta do jogo>/ninjaclient_vault_log.csv:
    // epoch_ms,nano_ms,modulo,posicao,item. Serve para descobrir se o sorteio do servidor tem padrao.
    private static final boolean LOG_SEQUENCE = true;
    // Com o log ligado, ao ativar o modulo comeca uma gravacao: cronometro na action bar (acima da
    // hotbar) e, ao zerar, a analise da sequencia aparece no chat (e vai para o arquivo de log).
    private static final int RECORD_SECONDS = 150;
    private record Seen(long nanos, String item) {}
    // quanto DEPOIS da troca (no servidor) o clique antecipado deve chegar. NAO calibrado: e uma
    // estimativa (~1 tick do servidor); ajuste medindo no seu servidor.
    private static final long LEAD_AFTER_SWITCH_NANOS = 60_000_000L;

    private final boolean ominousVault;
    private final Item wanted;
    private final Item key;
    private final int retryTicks;
    private final boolean predictive;
    private final Map<BlockPos, List<Seen>> session = new HashMap<>();
    private long sessionStart; // 0 = ainda nao comecou
    private boolean sessionDone;
    private final Map<BlockPos, VaultForecast<Item>> forecasts = new HashMap<>();

    private int timer;
    private int rescanTimer;
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    // vaults proximas guardadas em cache: assim a checagem a cada frame e barata
    private final List<BlockPos> nearby = new ArrayList<>();

    // todas as instancias (AutoVaultSuper, PotVault): o mixin de rede avisa todas de uma vez
    private static final List<VaultSniper> INSTANCES = new ArrayList<>();

    protected VaultSniper(String name, boolean ominousVault, Item wanted, Item key, int retryTicks) {
        this(name, ominousVault, wanted, key, retryTicks, false);
    }

    protected VaultSniper(String name, boolean ominousVault, Item wanted, Item key, int retryTicks,
                          boolean predictive) {
        super(name, Category.WORLD);
        this.predictive = predictive;
        this.ominousVault = ominousVault;
        this.wanted = wanted;
        this.key = key;
        this.retryTicks = retryTicks;
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        INSTANCES.add(this);

        // checa tambem a CADA FRAME (nao so a cada tick de 50 ms): o servidor troca o item
        // exibido rapido, entao quanto antes o clique sair, maior a chance de pegar o item certo
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("ninjaclient", "vault_" + name.toLowerCase()),
                (ctx, tickCounter) -> snipe());
    }

    /** Ao ligar com o log ativo: avisa no chat se a chave esta na hotbar (ela abriria a caixa e cortaria a gravacao). */
    @Override
    public void onEnable() {
        session.clear();
        sessionStart = 0;
        sessionDone = false;
        if (!predictive || !LOG_SEQUENCE || mc.player == null) return;
        if (findKeySlot() != -1) {
            mc.player.sendMessage(Text.literal("\u00a77[NinjaClient] \u00a7e" + name
                    + ": tire a chave da hotbar para gravar a sequencia da caixa"), false);
        }
    }

    @Override
    public void onDisable() {
        attempts.clear();
        forecasts.clear();
        session.clear();
        sessionStart = 0;
        sessionDone = false;
        nearby.clear();
        timer = 0;
        rescanTimer = 0;
    }

    @Override
    public void onTick() {
        recordTick();
        if (timer > 0) timer--;
        // a varredura (729 blocos) so a cada RESCAN_TICKS; o pacote da caixa (onVaultPacket) forca
        // uma na hora quando ainda nao ha nenhuma conhecida, entao a reacao nao atrasa
        if (rescanTimer-- <= 0) {
            rescan();
            rescanTimer = RESCAN_TICKS - 1;
        }
        snipe();
    }

    /**
     * Chamado pelo mixin de rede NO INSTANTE em que o pacote da caixa chega (antes do proximo
     * frame/tick): e o mais rapido possivel de reagir ao item exibido. O sorteio do
     * servidor so e previsivel se repetir um ciclo (ver VaultForecast); sem ciclo o ganho esta em
     * nao perder tempo.
     */
    public static void onVaultPacket() {
        for (VaultSniper m : INSTANCES) {
            if (!m.isEnabled()) continue;
            net.minecraft.client.MinecraftClient c = net.minecraft.client.MinecraftClient.getInstance();
            if (c.player == null || c.world == null) continue;
            if (m.nearby.isEmpty()) m.rescan();
            m.snipe();
        }
    }

    /** Procura as vaults do tipo certo no raio (feito so a cada 5 ticks). */
    private void rescan() {
        nearby.clear();
        BlockPos origin = mc.player.getBlockPos();
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dy = -RADIUS; dy <= RADIUS; dy++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (mc.world.getBlockEntity(p) instanceof VaultBlockEntity) nearby.add(p);
                }
            }
        }
    }

    /** Roda todo tick e todo frame: clica assim que o item exibido for o desejado. */
    private void snipe() {
        if (!isEnabled() || mc.player == null || mc.world == null) return;
        if (timer > 0 || mc.currentScreen != null) return;
        for (BlockPos pos : nearby) {
            if (handleVault(pos)) return; // uma acao por vez
        }
    }

    /** Retorna true se tentou abrir a caixa neste tick. */
    private boolean handleVault(BlockPos pos) {
        BlockEntity be = mc.world.getBlockEntity(pos);
        if (!(be instanceof VaultBlockEntity vault)) return false;

        BlockState state = mc.world.getBlockState(pos);
        if (!(state.getBlock() instanceof VaultBlock)) return false;
        if (state.get(VaultBlock.OMINOUS) != ominousVault) return false;
        if (state.get(VaultBlock.VAULT_STATE) != VaultState.ACTIVE) {
            forecasts.remove(pos); // caixa fora de ativa: a sequencia observada deixa de valer
            return false;
        }

        var shared = vault.getSharedData();
        boolean match = shared.hasDisplayItem() && shared.getDisplayItem().isOf(wanted);
        if (predictive) observe(pos, shared.hasDisplayItem() ? shared.getDisplayItem().getItem() : null);
        if (!match) {
            attempts.remove(pos); // item mudou: libera novas tentativas
            return predictive && tryPredictedClick(pos);
        }
        return open(pos);
    }

    /** Anuncia na action bar quando um ciclo e achado/perdido; guarda a observacao. */
    private void observe(BlockPos pos, Item shown) {
        VaultForecast<Item> f = forecasts.computeIfAbsent(pos, k -> new VaultForecast<>());
        int before = f.period();
        long now = System.nanoTime();
        if (!f.observe(now, shown)) return;
        String id = shown == null ? "none" : Registries.ITEM.getId(shown).toString();
        log(pos, id);
        if (sessionStart != 0 && !sessionDone) {
            session.computeIfAbsent(pos, k -> new ArrayList<>()).add(new Seen(now, id));
        }
        int after = f.period();
        if ((before == 0) != (after == 0)) {
            String msg = after > 0
                    ? "[" + name + "] ciclo de " + after + " itens (intervalo " + f.baseNanos() / 1_000_000L + " ms)"
                    : "[" + name + "] ciclo perdido: reagindo ao item exibido";
            mc.player.sendMessage(Text.literal(msg), false); // action bar e do cronometro
        }
    }

    private void log(BlockPos pos, String id) {
        if (!LOG_SEQUENCE) return;
        appendToLog(System.currentTimeMillis() + "," + System.nanoTime() / 1_000_000L + "," + name + ","
                + pos.getX() + " " + pos.getY() + " " + pos.getZ() + "," + id + "\n");
    }

    private void appendToLog(String text) {
        try {
            Path file = mc.runDirectory.toPath().resolve("ninjaclient_vault_log.csv");
            Files.writeString(file, text, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (java.io.IOException e) {
            // disco cheio/arquivo travado: o log e so diagnostico e nunca pode derrubar o modulo
        }
    }

    /** Cronometro regressivo na action bar; ao zerar, analisa o que foi gravado. */
    private void recordTick() {
        if (!predictive || !LOG_SEQUENCE || sessionDone) return;
        long now = System.nanoTime();
        if (sessionStart == 0) sessionStart = now;
        long left = RECORD_SECONDS * 1_000_000_000L - (now - sessionStart);
        if (left > 0) {
            long s = (left + 999_999_999L) / 1_000_000_000L;
            mc.player.sendMessage(Text.literal("\u00a77Gravando sequencia da caixa: \u00a7f"
                    + String.format("%d:%02d", s / 60, s % 60)), true);
            return;
        }
        sessionDone = true;
        finishSession();
    }

    private void finishSession() {
        String prefix = "\u00a77[NinjaClient] \u00a7e";
        if (session.isEmpty()) {
            mc.player.sendMessage(Text.literal(prefix + name
                    + ": nenhuma troca observada. Chegue perto de uma caixa suprema ATIVA e ligue de novo."), false);
            return;
        }
        for (Map.Entry<BlockPos, List<Seen>> e : session.entrySet()) {
            List<Long> times = new ArrayList<>();
            List<String> items = new ArrayList<>();
            for (Seen s : e.getValue()) {
                times.add(s.nanos());
                items.add(s.item());
            }
            BlockPos p = e.getKey();
            String head = name + " caixa " + p.getX() + " " + p.getY() + " " + p.getZ();
            String result = VaultAnalysis.report(times, items);
            mc.player.sendMessage(Text.literal(prefix + head), false);
            for (String line : result.split("\n")) {
                mc.player.sendMessage(Text.literal("\u00a7f" + line), false);
            }
            appendToLog("# " + head + " | " + result.replace("\n", " | ") + "\n");
        }
    }

    /**
     * Com ciclo confirmado: clica quando falta ~ping para o item desejado aparecer, para o clique
     * chegar ao servidor logo depois da troca. Sem ciclo, sem ping conhecido ou com o item ja
     * visivel, nao faz nada (o caminho reativo cuida).
     */
    private boolean tryPredictedClick(BlockPos pos) {
        VaultForecast<Item> f = forecasts.get(pos);
        if (f == null) return false;
        var handler = mc.getNetworkHandler();
        if (handler == null) return false;
        var entry = handler.getPlayerListEntry(mc.player.getUuid());
        long rtt = entry == null ? 0L : entry.getLatency() * 1_000_000L;
        if (rtt <= 0) return false; // ping desconhecido: nao antecipa
        long now = System.nanoTime();
        long arrival = f.predictArrival(wanted, now);
        if (arrival == VaultForecast.NONE) return false;
        long fireAt = arrival - rtt + LEAD_AFTER_SWITCH_NANOS;
        if (now < fireAt || now >= arrival) return false;
        return open(pos);
    }

    /** Clica na caixa com a chave certa (troca de slot e devolve). Retorna true se clicou. */
    private boolean open(BlockPos pos) {
        if (attempts.getOrDefault(pos, 0) >= MAX_ATTEMPTS) return false;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > RADIUS + 0.5) return false;

        int keySlot = findKeySlot();
        if (keySlot == -1) return false; // sem a chave certa na hotbar

        int previous = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(keySlot);

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        mc.player.getInventory().setSelectedSlot(previous);

        attempts.merge(pos, 1, Integer::sum);
        timer = retryTicks;
        return true;
    }

    private int findKeySlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(key)) return i;
        }
        return -1;
    }
}
