package com.meuclient.mixin;

import com.meuclient.modules.Capa;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Troca a capa e a elytra do SEU jogador pelas texturas do NinjaClient
 * (assets/ninjaclient/textures/capa.png e elytra.png). Os outros jogadores
 * nao sao afetados e nada e enviado ao servidor.
 */
@Mixin(AbstractClientPlayerEntity.class)
public class PlayerSkinMixin {
    private static final Identifier CAPE = Identifier.of("ninjaclient", "capa");
    private static final Identifier ELYTRA = Identifier.of("ninjaclient", "elytra");

    // guarda o ultimo resultado para nao criar objeto novo a cada frame
    private SkinTextures ninjaclient$lastBase;
    private SkinTextures ninjaclient$lastResult;

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void ninjaclient$customCape(CallbackInfoReturnable<SkinTextures> cir) {
        if (!Capa.isActive()) return;
        if ((Object) this != MinecraftClient.getInstance().player) return; // so o seu boneco

        SkinTextures base = cir.getReturnValue();
        if (base == null) return;
        if (base != ninjaclient$lastBase) {
            ninjaclient$lastBase = base;
            ninjaclient$lastResult = new SkinTextures(
                    base.body(),
                    new AssetInfo.TextureAssetInfo(CAPE),
                    new AssetInfo.TextureAssetInfo(ELYTRA),
                    base.model(),
                    base.secure());
        }
        cir.setReturnValue(ninjaclient$lastResult);
    }
}
